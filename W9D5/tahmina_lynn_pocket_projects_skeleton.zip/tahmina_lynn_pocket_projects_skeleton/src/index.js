import warmUp, { htmlGenerator } from "./warmup";
import clock from "./clock";
import dropDown from "./drop_down";
import toDoList from "./todo_list";

# == Schema Information
#
# Table name: cats
#
#  id          :bigint           not null, primary key
#  name        :string           not null
#  description :text
#  birth_date  :date             not null
#  color       :string           not null
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  sex         :string(1)        not null
#
class Cat < ApplicationRecord 
    include ActionView::Helpers::DateHelper
    
    
    COLOR =  ["Brown", "Orange", "Black", "White"]
    
    validates :name, :birth_date, presence: true 
    validates :color, inclusion: COLOR
    validates :sex, inclusion: ["M", "F"], presence: true 
    
    def age 
        from_time = birth_date
        distance_of_time_in_words_to_now(from_time)
    end 
end 

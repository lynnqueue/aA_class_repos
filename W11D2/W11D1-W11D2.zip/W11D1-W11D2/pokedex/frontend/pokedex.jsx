import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './store/store'
import Root from './root';
import { HashRouter, Route } from "react-router-dom";

import { receiveAPokemon } from './actions/pokemon_actions';
import * as APIUtil from './util/api_util';
// import { selectAllPokemon } from './reducers/selectors_reducer';

document.addEventListener('DOMContentLoaded', () => {
    const rootEl = document.getElementById('root');
    const store = configureStore();
    ReactDOM.render(<Root store={store} />, rootEl);

    // TESTING
    window.receiveAPokemon = receiveAPokemon;
    window.fetchAPokemon = APIUtil.fetchAPokemon;
    // window.getState = store.getState;
    // window.dispatch = store.dispatch;
    // window.requestAllPokemon = requestAllPokemon;
    // window.selectAllPokemon = selectAllPokemon;
});
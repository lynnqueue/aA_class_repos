import { combineReducers } from 'redux';
import entitiesReducer from './enitities_reducer';

const rootReducer = combineReducers({
    entities: entitiesReducer
});

export default rootReducer;
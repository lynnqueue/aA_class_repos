import React from 'react'
import { Link } from "react-router-dom";

const PokemonIndexItem = ({ pokemon }) => {
    return (
        <Link to={`/pokemon/${pokemon.id}`} >
            < li key={pokemon.id} >
                <img src={pokemon.image_url} alt={pokemon.name} />
                <br />
                {pokemon.name}
            </li >
        </Link >
    )
};

export default PokemonIndexItem;